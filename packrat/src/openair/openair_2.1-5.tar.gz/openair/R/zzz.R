 .onLoad <- function (...) {

 ##  packageStartupMessage("\ttype citation(\"openair\") for how to cite openair")

 }
