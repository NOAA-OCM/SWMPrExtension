qchi <-
function (p, df) 
{
    sqrt(qchisq(p, df))
}
