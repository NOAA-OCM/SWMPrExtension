space <-
function (n) 
{
    paste(rep(" ", n), sep = "", collapse = "")
}
