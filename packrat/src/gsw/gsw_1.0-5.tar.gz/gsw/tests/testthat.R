library(testthat)
library(gsw)

test_check("gsw")
