library(oce)
data(sealevel)
summary(sealevel)
plot(sealevel)
