library(oce)
d <- read.met("test_met.dat.gz")
summary(d)
plot(d)

